from game.scripts import main

mygame = main.Game()

mygame.run_editor()